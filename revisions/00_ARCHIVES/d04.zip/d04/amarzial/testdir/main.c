#include <stdio.h>
#include "ft_sqrt.c"

int main()
{
	printf("%d", ft_sqrt(16));
}
