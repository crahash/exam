#include "ft_putchar.c"
#include "ft_eight_queens_puzzle_2.c"

int main()
{
	ft_eight_queens_puzzle_2();
}
